CREATE TABLE clientes (
    id_cliente SERIAL PRIMARY KEY,
    nome VARCHAR(100),  
	email VARCHAR(150), 
    cidade VARCHAR(100)                  
);


CREATE TABLE Pedidos (
    id_pedido SERIAL PRIMARY KEY,       
    id_cliente INT,
	data_pedidos date,
    valor_total DECIMAL(10, 2),      
  FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
);


INSERT INTO clientes (nome, email, cidade) VALUES
('João Silva', 'joao@gmail.com', 'São Paulo'),
('Maria Souza', 'maria.souza@gmail.com', 'Rio de Janeiro'),
('Pedro Oliveira', 'pedro.oliver@gmail.com', 'Belo Horizonte');


INSERT INTO pedidos (id_cliente, data_pedidos, valor_total) VALUES
(1, '2024-11-01', 150.00),
(2, '2024-11-15', 250.00),
(3, '2024-11-20', 100.00);

SELECT  c.nome, c.email
FROM clientes c
JOIN pedidos p ON c.id_cliente = p.id_cliente
WHERE valor_total > 200.00;


SELECT cidade, count(*) as sla_clientes
FROM clientes GROUP BY cidade ORDER BY sla_clientes;



UPDATE clientes SET cidade= 'Curitiba'
	WHERE nome= 'Pedro Oliveira';

INSERT INTO Pedidos (id_cliente, data_pedidos, valor_total)
VALUES (2, CURRENT_DATE, 300.00);




select * from clientes
drop table clientes 

select * from pedidos
drop table pedidos 
